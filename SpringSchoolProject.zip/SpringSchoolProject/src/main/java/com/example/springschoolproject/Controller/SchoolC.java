package com.example.springschoolproject.Controller;

import com.example.springschoolproject.ApiResponse;
import com.example.springschoolproject.Model.Student;
import com.example.springschoolproject.Model.Teacher;
import com.example.springschoolproject.Service.SchoolService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;

@RestController
@RequestMapping("/api/v1")
@RequiredArgsConstructor
public class SchoolC {

    private final SchoolService School;

    @GetMapping("/stu/get")
   public ResponseEntity getStudnet(){
       ArrayList<Student> s = School.getStu();
       return ResponseEntity.status(200).body(s);
   }

   @GetMapping("/tea/get")
    public ResponseEntity getTeacher(){
        ArrayList<Teacher> s = School.getTeacher();
        return ResponseEntity.status(200).body(s);
    }
    @PostMapping("/stu/add")
    public ResponseEntity addStudent(@RequestBody Student s , Errors error){
       if(error.hasErrors()){
           String M = error.getFieldError().getDefaultMessage();
           return ResponseEntity.status(400).body(M);
       }
       School.addStu(s);
        return ResponseEntity.status(201).body(new ApiResponse("Student added!"));
    }

    @PostMapping("/tea/add")
    public ResponseEntity addTeacher(@RequestBody Teacher t , Errors error){
        if(error.hasErrors()){
            String M = error.getFieldError().getDefaultMessage();
            return ResponseEntity.status(400).body(M);
        }
        School.addTeacher(t);
        return ResponseEntity.status(201).body(new ApiResponse("Teacher added!"));
    }

    @PutMapping("/stu/update/{ID}")
    public ResponseEntity updateStudent(@RequestBody Student s ,  @PathVariable Integer ID ,Errors error ){
        if(error.hasErrors()){
            String M = error.getFieldError().getDefaultMessage();
            return ResponseEntity.status(400).body(M);
        }
        boolean isUpdated = School.updateStu(ID, s);
        if(isUpdated)
            return ResponseEntity.status(200).body(new ApiResponse("Student updated!"));
        else
            return ResponseEntity.status(400).body(new ApiResponse("ID not found!"));

    }

    @PutMapping("/tea/update/{ID}")
    public ResponseEntity updateTeacher(@RequestBody Teacher t ,  @PathVariable Integer ID ,Errors error ){
        if(error.hasErrors()){
            String M = error.getFieldError().getDefaultMessage();
            return ResponseEntity.status(400).body(M);
        }
        boolean isUpdated = School.updateTeacher(ID, t);
        if(isUpdated)
            return ResponseEntity.status(200).body(new ApiResponse("Teacher updated!"));
        else
            return ResponseEntity.status(400).body(new ApiResponse("ID not found!"));
    }

    @DeleteMapping("/tea/delete/{ID}")
    public ResponseEntity deleteTeacher(@PathVariable Integer ID ,Errors error ){
        if(error.hasErrors()){
            String M = error.getFieldError().getDefaultMessage();
            return ResponseEntity.status(400).body(M);
        }
        boolean isDeleted = School.DeleteTeacher(ID);
        if(isDeleted)
            return ResponseEntity.status(200).body(new ApiResponse("Teacher deleted!"));
        else
            return ResponseEntity.status(400).body(new ApiResponse("ID not found!"));
    }

    @DeleteMapping("/stu/delete/{ID}")
    public ResponseEntity deleteStudent(@PathVariable Integer ID ,Errors error ){
        if(error.hasErrors()){
            String M = error.getFieldError().getDefaultMessage();
            return ResponseEntity.status(400).body(M);
        }
        boolean isDeleted = School.DeleteStu(ID);
        if(isDeleted)
            return ResponseEntity.status(200).body(new ApiResponse("Student deleted!"));
        else
            return ResponseEntity.status(400).body(new ApiResponse("ID not found!"));
    }

    @GetMapping("/stu/{ID}")
    public ResponseEntity getStuById(@PathVariable Integer ID  ){

        int index = School.getStuById(ID);
        if(index == -1)
            return ResponseEntity.status(400).body(new ApiResponse("student id not found"));
        else
            return ResponseEntity.status(200).body(School.getStu().get(index));
    }

    @GetMapping("/tea/{ID}")
    public ResponseEntity getTeaById(@PathVariable Integer ID ){

        int index = School.getTeaById(ID);
        if(index == -1)
            return ResponseEntity.status(400).body(new ApiResponse("Teacher id not found"));
        else
            return ResponseEntity.status(200).body(School.getTeacher().get(index));
    }

    @GetMapping("/stu/{Name}")
    public ResponseEntity getStuByName(@PathVariable String Name){
        int index = School.getStuByName(Name);
        if(index == -1)
            return ResponseEntity.status(400).body(new ApiResponse("student name not found"));
        else
            return ResponseEntity.status(200).body(School.getStu().get(index));
    }

    @GetMapping("stu/{Major}")
    public ResponseEntity getStuMajor(@PathVariable String Major){
        ArrayList<Student> s = School.getStuMajor(Major);
            return ResponseEntity.status(200).body(s);
    }

    @GetMapping("/tea/{Salary}")
    public ResponseEntity getTeacherSalary(@PathVariable Double Salary ){
        ArrayList<Teacher> t = School.getTeaSalary(Salary);
        return ResponseEntity.status(200).body(t);
    }

    @GetMapping("/stu/{age}")
    public ResponseEntity getStuAge(@PathVariable Integer age){
        ArrayList<Student> s = School.getStuAge(age);
        return ResponseEntity.status(200).body(s);
    }
}
