package com.example.springschoolproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSchoolProjectApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringSchoolProjectApplication.class, args);
    }

}
