package com.example.springschoolproject.Service;

import com.example.springschoolproject.Model.Student;
import com.example.springschoolproject.Model.Teacher;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class SchoolService {

   ArrayList<Student> stu = new ArrayList<>();
   ArrayList<Teacher> teacher = new ArrayList<>();

   public ArrayList<Student> getStu() {
       return stu;
   }

    public  ArrayList<Teacher> getTeacher() {
        return teacher;
    }

    public void addStu(Student u){
       stu.add(u);
    }

    public void addTeacher(Teacher u){
        teacher.add(u);
    }

    public boolean updateStu(Integer Id , Student u){
       for (int i = 0 ; i < stu.size() ; i++){
           if(stu.get(i).getID() == Id){
               stu.set(i,u);
               return true;
           }
       }
       return false;
    }

    public boolean updateTeacher(Integer Id , Teacher u){
        for (int i = 0 ; i < teacher.size() ; i++){
            if(teacher.get(i).getID() == Id){
                teacher.set(i,u);
                return true;
            }
        }
        return false;
    }

    public boolean DeleteStu(Integer Id){
        for (int i = 0 ; i < stu.size() ; i++){
            if(stu.get(i).getID() == Id){
                stu.remove(i);
                return true;
            }
        }
        return false;
    }

    public boolean DeleteTeacher(Integer Id){
        for (int i = 0 ; i < teacher.size() ; i++){
            if(teacher.get(i).getID() == Id){
                teacher.remove(i);
                return true;
            }
        }
        return false;
    }

    public int getStuById(Integer Id) {
        for (int i = 0 ; i < stu.size() ; i++){
            if(stu.get(i).getID() == Id){
                return i;
            }
        }
       return -1;
    }

    public int getTeaById(Integer Id) {
        for (int i = 0 ; i < teacher.size() ; i++){
            if(teacher.get(i).getID() == Id){
                return i;
            }
        }
        return -1;
    }

    public int getStuByName(String name) {
        for (int i = 0 ; i < stu.size() ; i++){
            if(stu.get(i).getName() == name){
                return i;
            }
        }
        return -1;
    }

    public ArrayList<Student> getStuMajor(String Major){
    ArrayList<Student> major = new ArrayList<>();
        for(int i = 0 ; i < stu.size() ; i++){
            if(stu.get(i).getMajor() == Major){
                major.add(stu.get(i));
            }
        }
        return major;
    }

    public ArrayList<Teacher> getTeaSalary(Double salary){
        ArrayList<Teacher> Salary = new ArrayList<>();
        for(int i = 0 ; i < teacher.size() ; i++){
            if(teacher.get(i).getSalary() >= salary ){
                 Salary.add(teacher.get(i));
            }
        }
        return Salary;
    }

    public ArrayList<Student> getStuAge(Integer age){
        ArrayList<Student> Age = new ArrayList<>();
        for(int i = 0 ; i < stu.size() ; i++){
            if(stu.get(i).getAge() >= age){
                Age.add(stu.get(i));
            }
        }

        return Age;
    }
}
