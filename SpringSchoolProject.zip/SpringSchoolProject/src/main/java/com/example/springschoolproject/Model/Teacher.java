package com.example.springschoolproject.Model;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Teacher {
    //  ID , name , salary ( all should not be empty)
    @NotNull(message = "ID shouldn't be empty")
    @Positive(message = "ID must be positive")
    private Integer ID;
    @NotEmpty(message = "name shouldn't be empty")
    private String name;
    @NotNull(message = "salary shouldn't be empty")
    @Positive(message = "salary must be positive")
    private Double salary;
}
