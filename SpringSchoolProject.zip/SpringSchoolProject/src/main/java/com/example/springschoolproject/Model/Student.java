package com.example.springschoolproject.Model;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Student {

    /*  ID , name , age , major ( all should not be empty ) ( major enum {CS , MATH , Engineer} )
    - no negative numbers
     */
    @NotNull(message = "ID shouldn't be empty")
    @Positive(message = "ID must be positive")
    private Integer ID;
    @NotEmpty(message = "name shouldn't be empty")
    private String name;
    @NotNull(message = "age shouldn't be empty")
    @Positive(message = "age must be positive")
    private Integer age;
    @NotEmpty(message = "major shouldn't be empty")
    @Pattern(regexp = "(CS|MATH|Engineer)")
    private String major;

}
