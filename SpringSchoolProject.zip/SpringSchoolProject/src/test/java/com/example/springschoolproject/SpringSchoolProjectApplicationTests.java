package com.example.springschoolproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSchoolProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
